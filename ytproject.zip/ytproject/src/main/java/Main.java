import views.welcome;
public class Main {
    public static void main(String[] args) {
        welcome w =new welcome();
        do{
            w.welcomeScreen();
        }while(true);
    }
}
