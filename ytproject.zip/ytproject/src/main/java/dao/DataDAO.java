package dao;

import db.MyConnection;
import model.Data;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DataDAO {

    public static List<Data> getAllFiles(String email) throws ClassNotFoundException, SQLException {
        String query = "SELECT id, name, path FROM data WHERE email = ?";
        List<Data> files = new ArrayList<>();
        try (Connection connection = MyConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    files.add(new Data(rs.getInt(1), rs.getString(2), rs.getString(3)));
                }
            }
        }
        return files;
    }

    public static int hideFile(Data file) throws IOException, SQLException {
        String query = "INSERT INTO data (name, path, email, bin_data) VALUES (?, ?, ?, ?)";
        try (Connection connection = MyConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(query);
             FileReader fr = new FileReader(new File(file.getPath()))) {
            ps.setString(1, file.getFileName());
            ps.setString(2, file.getPath());
            ps.setString(3, file.getEmail());
            ps.setCharacterStream(4, fr);
            int result = ps.executeUpdate();
            new File(file.getPath()).delete();
            return result;
        }
    }

    public static void unhide(int id) throws IOException, SQLException {
        String selectQuery = "SELECT path, bin_data FROM data WHERE id = ?";
        String deleteQuery = "DELETE FROM data WHERE id = ?";
        try (Connection connection = MyConnection.getConnection();
             PreparedStatement selectPs = connection.prepareStatement(selectQuery)) {
            selectPs.setInt(1, id);
            try (ResultSet rs = selectPs.executeQuery()) {
                if (rs.next()) {
                    String path = rs.getString(1);
                    Clob binData = rs.getClob(2);
                    try (Reader reader = binData.getCharacterStream();
                         FileWriter writer = new FileWriter(path)) {
                        int c;
                        while ((c = reader.read()) != -1) {
                            writer.write(c);
                        }
                    }
                }
            }
            try (PreparedStatement deletePs = connection.prepareStatement(deleteQuery)) {
                deletePs.setInt(1, id);
                deletePs.executeUpdate();
            }
        }
    }
}
