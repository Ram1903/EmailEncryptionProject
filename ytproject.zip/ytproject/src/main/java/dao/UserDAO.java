package dao;

import db.MyConnection;
import model.User;

import java.sql.*;

public class UserDAO {

    public static boolean isExists(String email) throws SQLException {
        Connection connection = MyConnection.getConnection();
        String query = "SELECT email FROM users WHERE email = ?";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setString(1, email);
        ResultSet rs = ps.executeQuery();
        boolean exists = rs.next(); // If a record is found, email exists
        rs.close();
        ps.close();
        connection.close();
        return exists;
    }

    public static int saveUser(User user) throws SQLException {
        Connection connection = MyConnection.getConnection();
        String query = "INSERT INTO users (name, email) VALUES (?, ?)";
        PreparedStatement ps = connection.prepareStatement(query);
        ps.setString(1, user.getName());
        ps.setString(2, user.getEmail());
        int result = ps.executeUpdate();
        ps.close();
        connection.close();
        return result;
    }
}
