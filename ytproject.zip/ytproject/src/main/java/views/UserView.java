package views;

import dao.DataDAO;
import model.Data;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class UserView {

    private String email;

    UserView(String email) {
        this.email = email;
    }

    public void home() {
        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("Welcome " + this.email);
            System.out.println("Press 1 to show hidden files");
            System.out.println("Press 2 to hide new file");
            System.out.println("Press 3 to unhide file");
            System.out.println("Press 0 to exit");

            int ch = Integer.parseInt(sc.nextLine());
            switch (ch) {
                case 1: {
                    try {
                        List<Data> files = DataDAO.getAllFiles(this.email);
                        System.out.println("ID - File Name");
                        for (Data file : files) {
                            System.out.println(file.getId() + " - " + file.getFileName());
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;
                }

                case 2: {
                    System.out.println("Enter the file path:");
                    String path = sc.nextLine();
                    File f = new File(path);
                    if (!f.exists()) {
                        System.out.println("File does not exist at the provided path.");
                    } else {
                        Data file = new Data(0, f.getName(), path, this.email);
                        try {
                            DataDAO.hideFile(file);
                            System.out.println("File successfully hidden.");
                        } catch (IOException | SQLException e) {
                            System.out.println("Error hiding the file: " + e.getMessage());
                            e.printStackTrace();
                        }
                    }
                    break;
                }

                case 3: {
                    List<Data> files = null;
                    try {
                        files = DataDAO.getAllFiles(this.email);
                        if (files.isEmpty()) {
                            System.out.println("No hidden files found.");
                        } else {
                            System.out.println("ID - File Name");
                            for (Data file : files) {
                                System.out.println(file.getId() + " - " + file.getFileName());
                            }
                            System.out.println("Enter the ID of the file to unhide:");

                            int id = Integer.parseInt(sc.nextLine());
                            boolean isValidID = false;
                            for (Data file : files) {
                                if (file.getId() == id) {
                                    isValidID = true;
                                    break;
                                }
                            }
                            if (isValidID) {
                                DataDAO.unhide(id);
                                System.out.println("File successfully unhidden.");
                            } else {
                                System.out.println("Invalid file ID.");
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("Error fetching hidden files: " + e.getMessage());
                        e.printStackTrace();
                    }
                    break;
                }

                case 0: {
                    System.out.println("Exiting the application. Goodbye!");
                    System.exit(0);
                    break;
                }

                default: {
                    System.out.println("Invalid choice. Please try again.");
                    break;
                }
            }
        } while (true);
    }
}
