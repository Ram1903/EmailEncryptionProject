package views;

import dao.UserDAO;
import model.User;
import service.GenerateOTP;
import service.SendOTPService;
import service.UserService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class welcome {
    public void welcomeScreen() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Welcome to the application");
        System.out.println("Press 1 to Login");
        System.out.println("Press 2 to Signup");
        System.out.println("Press 0 to Exit");
        int choice = 0;
        try {
            choice = Integer.parseInt(br.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch (choice) {
            case 1:
                login();
                break;
            case 2:
                signUp();
                break;
            case 0:
                System.exit(0);
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private void login() {
        System.out.println("Enter email");
        Scanner sc = new Scanner(System.in);
        String email = sc.nextLine();
        try {
            UserDAO userDAO = new UserDAO();
            if (userDAO.isExists(email)) {
                String genOTP = GenerateOTP.getOTP();
                SendOTPService.sendOTP(email, genOTP);
                System.out.println("Enter your OTP");
                String otp = sc.nextLine();
                if (otp.equals(genOTP)) {
                    new UserView(email).home();
                } else {
                    System.out.println("Invalid OTP");
                }
            } else {
                System.out.println("User not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void signUp() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter your name");
        String name = sc.nextLine();
        System.out.println("Enter Email");
        String email = sc.nextLine();
        String genOTP = GenerateOTP.getOTP();
        SendOTPService.sendOTP(email, genOTP);
        System.out.println("Enter your OTP");
        String otp = sc.nextLine();

        if (otp.equals(genOTP)) {
            User user = new User(name, email);
            UserService userService = new UserService();
            Integer response = userService.saveUser(user);
            if (response == null) {
                System.out.println("Error saving user. Try again later.");
                return;
            }
            switch (response) {
                case 0:
                    System.out.println("User created");
                    break;
                case 1:
                    System.out.println("User already exists");
                    break;
                default:
                    System.out.println("Unknown error occurred.");
            }
        } else {
            System.out.println("Invalid OTP");
        }
    }
}
